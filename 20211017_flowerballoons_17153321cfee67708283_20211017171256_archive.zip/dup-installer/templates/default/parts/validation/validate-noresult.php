<?php
/**
 *
 * @package templates/default
 *
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="validate-no-result" class="text-center" >
    <p>Not validated yet, please click validate button.</p>
</div>