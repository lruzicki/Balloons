<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Last Name</td>
    <td>Last name of the user being created. Optional.</td>
</tr>