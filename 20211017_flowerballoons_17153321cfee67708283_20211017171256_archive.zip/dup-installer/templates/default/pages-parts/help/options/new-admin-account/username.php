<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Username</td>
    <td>Username of the user being created. This will be used as the login for the new administrator account.  Please note that usernames are not changeable from the within the WordPress UI.  Mandatory Field.</td>
</tr>