<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Extract</td>
    <td>
        Indicates table will be installed. Turn off this switch to prevent the table installation. Option is on by default.
    </td>
</tr>