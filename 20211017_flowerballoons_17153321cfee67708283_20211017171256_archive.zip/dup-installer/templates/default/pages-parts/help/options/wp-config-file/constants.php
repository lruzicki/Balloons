<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Constants</td>
    <td>
        The wp-config tab contains the list of constants that can be modified directly by the installer.<br>
        See the <a href="https://wordpress.org/support/article/editing-wp-config-php/" target="_blank">WordPress documentation for more information</a>.
    </td>
</tr>