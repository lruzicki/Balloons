<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">User</td>
    <td>The name of a MySQL database server user. This is special account that has privileges to access a database and can read from or write to that database.
        <i>This is <b>not</b> the same thing as your WordPress administrator account</i>.</td>
</tr>