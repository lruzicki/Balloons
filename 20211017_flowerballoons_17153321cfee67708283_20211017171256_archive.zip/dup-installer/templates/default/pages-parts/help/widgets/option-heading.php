<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <th class="col-opt">Option</th>
    <th>Details</th>
</tr>