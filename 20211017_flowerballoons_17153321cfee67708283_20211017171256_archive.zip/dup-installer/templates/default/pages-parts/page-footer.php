<?php
/**
 *
 * @package templates/default
 *
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
</div>
<?php
DUPX_Params_Manager::getInstance()->getParamsHtmlInfo();
?>
</body>
</html>

